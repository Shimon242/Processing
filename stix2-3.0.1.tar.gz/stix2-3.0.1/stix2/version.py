__version__ = "3.0.1"

DEFAULT_VERSION = '2.1'  # Default version will always be the latest STIX 2.X version
